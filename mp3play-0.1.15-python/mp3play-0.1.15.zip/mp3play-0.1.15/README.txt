Several useful example scripts are available at

  http://code.google.com/p/mp3play/wiki/Examples

and an example script to get you started is in example.py.  To run it, type

  python.exe example.py

in your Python directory.

Questions?  Visit the project page at http://mp3play.googlecode.com .

Thanks.
Michael Gundlach
gundlach@gmail.com
